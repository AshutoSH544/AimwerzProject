package com.bank.util;

public class InactiveUserExecption {

}
