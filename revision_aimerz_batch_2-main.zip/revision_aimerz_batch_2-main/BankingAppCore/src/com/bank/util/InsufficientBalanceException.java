package com.bank.util;

public class InsufficientBalanceException {

}
