package com.bank.util;

public class InvalidAccountNumberException {

}
