package com.bank.util;

public class InavlidOtpExecption {

}
