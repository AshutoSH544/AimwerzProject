package com.bank.beans;

public class SavingsAccount extends Account {

}
