package com.bank.beans;

public class CurrentAccount extends Account
{

}
