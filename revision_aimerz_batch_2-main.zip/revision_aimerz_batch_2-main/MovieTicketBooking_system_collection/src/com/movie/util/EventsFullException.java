package com.movie.util;

public class EventsFullException extends RuntimeException 
{
	public EventsFullException(String message)
	{
		super(message);
	}

}
