package com.movie.entity;

public class Review
{
	int id;
	int userId;
	String username;
	double ratings;
	String review;

}
