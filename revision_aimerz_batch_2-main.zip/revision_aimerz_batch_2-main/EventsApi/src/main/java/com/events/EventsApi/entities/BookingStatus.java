package com.events.EventsApi.entities;

public enum BookingStatus 
{
	NOT_PAID,CANCELLED,CONFIRMED

}
