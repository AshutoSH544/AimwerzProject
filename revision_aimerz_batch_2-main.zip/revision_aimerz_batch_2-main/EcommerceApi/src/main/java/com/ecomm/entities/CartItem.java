//package com.ecomm.entities;
//
//import java.util.Set;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.ManyToOne;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//
//@Data
//@Entity
//@NoArgsConstructor
//@AllArgsConstructor
//public class CartItem 
//{
//	@Id
//	private int id;
//	
//	@ManyToOne
//	private Cart cart;
//	
//	@ManyToOne
//	private Product product;
//	
//	private int quantity;
//	
//
//}
