//package com.ecomm.entities;
//
//import java.util.Set;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.OneToMany;
//import jakarta.persistence.OneToOne;
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@Entity
//@NoArgsConstructor
//@AllArgsConstructor
//public class Cart
//{
//	@Id
//	private int id;	
//	@OneToOne
//	private User user;
//	@OneToMany
//	private Set<CartItem> cartItem;
//
//}
