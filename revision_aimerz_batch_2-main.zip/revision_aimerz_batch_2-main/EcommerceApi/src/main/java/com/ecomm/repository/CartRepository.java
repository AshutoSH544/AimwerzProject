//package com.ecomm.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.ecomm.entities.Cart;
//
//public interface CartRepository extends JpaRepository<Cart, Integer> {
//
//}
