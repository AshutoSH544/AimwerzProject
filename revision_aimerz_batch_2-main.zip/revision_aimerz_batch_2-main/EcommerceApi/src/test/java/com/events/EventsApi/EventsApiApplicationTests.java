package com.events.EventsApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
