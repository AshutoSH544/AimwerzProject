package com.events.entity;

public class User {

}
