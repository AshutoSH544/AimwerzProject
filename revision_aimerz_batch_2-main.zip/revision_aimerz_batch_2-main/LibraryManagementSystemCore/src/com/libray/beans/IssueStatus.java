package com.libray.beans;

public enum IssueStatus 
{
	APPROVED,CANCELLED,PENDING

}
