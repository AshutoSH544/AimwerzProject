package com.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommApiApplication.class, args);
	}

}
